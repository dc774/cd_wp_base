<?php

$content = cd_wp_base_content_vars();

?>

<div class="article">
	<InnerBlocks
		template='<?php echo $content["default_blocks"]; ?>'
	/>
</div>
