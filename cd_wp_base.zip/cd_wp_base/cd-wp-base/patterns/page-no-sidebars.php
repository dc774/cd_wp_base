<?php
/**
 * Title: Page (No Sidebars)
 * Slug: cd-wp-base/page-no-sidebars
 * Categories: pages
 */
?>
<!-- wp:template-part {"slug":"header","tagName":"header","area":"header"} /-->
<!-- wp:cd/content {"name":"cd/content","data":{"field_68a35548a985c":"no-sidebar","field_68a35602a985d":"article-width","field_68ab55562f9ee":"medium","field_68a5e2a0bc833":"1","field_68ab3968567b1":"edge"},"mode":"preview"} -->
	<!-- wp:cd/article {"name":"cd/article","mode":"preview"} -->
		<!-- wp:cd/breadcrumb {"name":"cd/breadcrumb","mode":"preview"} /-->
		<!-- wp:cd/title {"name":"cd/title","mode":"preview"} /-->
		<!-- wp:post-content /-->
	<!-- /wp:cd/article -->
<!-- /wp:cd/content -->
<!-- wp:template-part {"slug":"footer","tagName":"footer","area":"footer"} /-->
