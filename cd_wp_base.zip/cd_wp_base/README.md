# CD WP Base Theme

A streamlined WordPress block theme that can be used as a standalone lightweight Cornell-branded theme, or as a parent theme when working on a custom project.

## Goals

* Update our WP base theme to a modern block theme format while retaining useful features from the previous version of our theme
* Reduce time and effort to start new WP projects
* Allow our team and customers to more easily customize the look and feel of sites
* Reduce unnecessary dependencies on third-party plugins

## Getting Started

For the time being, this theme can be manually downloaded into projects as needed. We're planning to eventually create a script to allow members of our team to automatically download this theme, necessary plugins, and a scaffolded child theme all at once.

### Installation

1. Create or pull down a site locally in which to install this theme
1. Download the CD WP Base Theme from GitHub by clicking the "Code" dropdown and selecting "Download ZIP"
1. Unzip the GitHub download and copy the `cd-wp-base` subdirectory into your site's `themes` directory
1. Activate the CD WP Base Theme

## Contributing

Anyone on the Custom Dev team is welcome and encouraged to contribute! See [CONTRIBUTING](https://github.com/CornellCustomDev/cd_wp_base/blob/main/CONTRIBUTING.md) for details on how to get involved.
