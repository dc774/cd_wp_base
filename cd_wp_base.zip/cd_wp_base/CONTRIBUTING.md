# Contributing to the CD WP Base Theme

## Getting Started

We recommend using the [CD WP Atlas site](https://dashboard.pantheon.io/sites/cfda6aad-f6be-4c46-99dc-5bcb9eb56996) for local development, since it uses our standard Pantheon site configuration and has all of the plugins we typically use on our sites. However, you can also create a fresh WP site locally and work from there if you prefer.

In either case, always make sure to create a new branch before making any changes (don't work directly on the **`main`** branch)!

### Prerequisites

* We recommend installing [WP CLI](https://wp-cli.org/#installing)
* Make sure your editor supports .editorconfig files
	* **PHPStorm** will work out of the box
	* **VSCode** requires [a plugin](https://marketplace.visualstudio.com/items?itemName=EditorConfig.EditorConfig)
	* **Sublime** requires [a plugin](https://github.com/sindresorhus/editorconfig-sublime#readme)
	* For other editors, refer to the editor list on the [Editor Config website](https://editorconfig.org/#pre-installed)

### Local Development Setup

#### Using Atlas

Because Pantheon doesn't allow git submodules, there's an extra step to connect the base theme's git repo to your local copy of the theme within the Atlas project. You should (hopefully) only have to do this when you first set up Atlas locally.

1. Set up a local development environment for [Atlas](https://dashboard.pantheon.io/sites/cfda6aad-f6be-4c46-99dc-5bcb9eb56996) however you typically would
1. Navigate into the themes directory: `cd wp-content/themes`
1. Remove the base theme directory: `rm -rf cd_wp_base`
1. Re-clone the base theme from GitHub: `git clone git@github.com:CornellCustomDev/cd_wp_base.git`

If the Atlas site was in sync with our theme repo on GitHub, you shouldn't see any changed files, but you can now push changes to both GitHub and Pantheon from the same local development evironment (simply navigate into the theme directory to push to the GitHub repo, and navigate to any directory above it to push to the Pantheon site).

**Note:** only changes from the `main` branch of the GitHub repo should be pushed to the Atlas dev environment; if you're making changes to the theme that have not yet been merged into `main`, please keep them local or in a multidev!

#### Fresh Install

1. Create a directory for your new WP site
1. From inside the site directory, run this WP CLI command to download a fresh install of WP without default themes or plugins: `wp core download --skip-content`
1. Navigate into the themes directory of your new site: `cd wp-content/themes`
1. Clone the WP Base Theme repo: `git clone git@github.com:CornellCustomDev/cd_wp_base.git`
1. Activate the theme on your site

## Development Standards

We use the [WordPress Coding Standards](https://developer.wordpress.org/coding-standards/wordpress-coding-standards/) as a general guideline, with some exceptions based on the preferences of our team. Decisions on coding standards are still ongoing, since this project is fairly young – if you want to vary from WP standards in a way that's not listed here, check in with the team and we can discuss it!

### Linting

We use [Super Linter](https://github.com/super-linter/super-linter) to automatically check our code for style and syntax issues. Super Linter runs as a GitHub Action whenever a pull request is created. It uses a collection of linters to validate the code and outputs any violations of coding standards directly in the pull request checks.

The linter configuration file is located here: `.github/workflows/super-linter.yml`
The PHP Code Sniffer customizations file is located here: `.github/linters/phpcs.xml`

If a linter check fails, all style and syntax errors must be manually fixed in a new commit before the code can be merged. Since this is a new process, please bring any questions, false positives, or suggestions about linter errors to the team for discussion.

#### Local Linting

Contributors can optionally run [Super Linter locally](https://github.com/super-linter/super-linter/blob/main/docs/run-linter-locally.md) before commiting code using the following steps.

1. Make sure Docker is running
2. Navigate to the root of this repository
3. Run the following script:

	*Note: The first time will take awhile as it is building the Docker image*

	On Mac:
	```
	docker run --rm \
	-e RUN_LOCAL=true \
	--platform linux/amd64 \
	--env-file ".github/workflows/super-linter.env" \
	-v "$(pwd)":/tmp/lint \
	github/super-linter:latest
	```
	On Windows/Linux:
	```
	docker run --rm \
	-e RUN_LOCAL=true \
	--env-file ".github/workflows/super-linter.env" \
	-v "$(pwd)":/tmp/lint \
	github/super-linter:latest
	```
This script can be run any time the user would like to lint their codebase. Note: the referenced .env file `.github/workflows/super-linter.env` is a way to emulate our linting preferences locally. If you would like to modify the environment variables for whatever reason you can remove that line and add your own, [referenced here](https://github.com/super-linter/super-linter?tab=readme-ov-file#configure-super-linter).

### PHP Coding Standards

Follow WP's [PHP Coding Standards](https://developer.wordpress.org/coding-standards/wordpress-coding-standards/php/), with the following exceptions:

* **Less Whitespace**
	* Do not include a space after `!` when negating variables
		* ❌ `! $foo`
		* ✅ `!$foo`
	* Do not include extra space inside parentheses
		* ❌ `foreach ( $foo as $bar ) {...}`
		* ✅ `foreach ($foo as $bar) {...}`
	* Do not include spaces in array brackets, even for variable names
		* ❌ `$foo[ $bar ]`
		* ✅ `$foo[$bar]`
	* Only use multiline function calls if necessary to prevent an extremely long line of code (currently up to personal judgment but we may set a character limit in the future)
		* ❌
			```
				function_name(
					arg1,
					arg2
				);
			```
		* ✅ `function_name(arg1, arg2);`
* Do not use **Yoda Conditionals**
	* ❌ `if (true == $foo) {...}`
	* ✅ `if ($foo == true) {...}`
* **Variable assignment in conditionals** is allowed in template files, only when not doing so would cause extensive extra PHP tags, for example:
	```
	<?php if ($var = get_field('var')): ?>
		<p><?php echo $var; ?></p>
	<?php endif; ?>
	```

### Theme-Specific Standards

#### Function Prefix

`cd_wp_base_` should be used as the prefix for all function names.

#### WP Hooks

WordPress hooks (e.g. actions or filters) should be listed **above** their callback function, to make it easier to see how that function is being used without having to read through the entire thing. For example:

```
add_action('wp_action_name', 'cd_wp_base_function');

function cd_wp_base_function() {
	...
}
```

#### Function Comments

All custom functions should have a comment directly above them (or above the action/filter if the function is a callback for a WP hook) that states what the function does. This doesn’t have to be particularly extensive or follow any specific formatting.

#### "Function Exists" Conditionals

Almost all functions in the base theme should be wrapped in a conditional that checks if the function already exists; this allows child themes to override these functions by creating a function with the same name. For example:

```
if (!function_exists('cd_wp_base_function_name')) {
	function cd_wp_base_function_name() {
		...
	}
}
```

The only exception is if the function absolutely **cannot** be overridden in the child theme for some reason. In this case, the conditional can be omitted, but the comment explaining the function's purpose should also explain why it cannot be overridden.

#### Use `get_theme_file_path` to include PHP

When loading PHP files, use WP's `get_theme_file_path` function. For example:

```
require_once get_theme_file_path('functions/custom-functions.php');
```

This function checks for the file in the child theme first and then in the parent theme, which allows child themes to override the file by creating one with the same name.

#### PHP Partials & `functions.php`

**No custom code should be added directly to the `functions.php` file.**

All functions should be grouped by purpose (e.g. block editor configuration or theme setup) and located in a logically-named file in the `functions/` directory of the theme. Each PHP partial should then be included in `functions.php` using the `require_once get_theme_file_path()` format shown above.

Initially, all function files should be located directly in the main `functions/` directory; as the theme grows, we can add subdirectories to help with organization if needed.

## Development Workflow

All work should be done on a feature branch and then reviewed and approved by at least one other person via a GitHub pull request before being merged to the main branch.

### Pull Request Creation

There is a [pull request template](https://github.com/CornellCustomDev/cd_wp_base/blob/main/.github/pull_request_template.md) to help outline your PR description. In addition to what is in the template, please include any additional information or context that may help inform the review process.

Once you submit a PR, your code will be reviewed by an automatic linter to make sure it follows our coding standards. Please try to fix any legitimate errors immediately; if it returns any false positives, you can instead leave a comment on the PR explaining why the check failed.

### Pull Request Review

There are generally two types of review feedback:

#### Must Fix Issues

* Bugs
* Potential maintenance issues
* Coding standard issues
* Performance issues
* Not meeting the understood need that the PR is addressing

#### Recommendations

* Optimization issues
* Architectural changes
* Style issues

When adding a recommendation (rather than a "must fix"), make sure the changes are worth the time and support our project goals (see [README](https://github.com/CornellCustomDev/cd_wp_base/blob/main/README.md)).

When acting upon recommendations, presume that the review comment should be implemented unless there is a reason not to.

### Merging & Versioning

Our base theme uses semantic versioning (i.e. X.Y.Z – [major version].[minor version].[patch]). The theme version can be located in two places (which should always match):

1. The latest release on GitHub
1. The version attribute in the doc block of `style.css`.

This makes it easier to support sites as we continue building out the theme, by allowing us to see which version of the theme a site is using and check the GitHub release notes to see what has changed since then. We do not currently have any automations around versioning, which means there are a few extra steps when merging a pull request:

1. Immediately after merging, edit `style.css` on the `main` branch and increase the version number, following semantic versioning (ask the team if you're unclear how the version should increase!)
1. Push the `style.css` change up to GitHub immediately (this is the **only** change that we do not require a PR for)
1. On the [main repo page](https://github.com/CornellCustomDev/cd_wp_base) in GitHub, find the "Releases" section on the righthand side and click "Create a new release"
1. In the "Choose a tag" dropdown, add a tag for this release with the same version you just added to `style.css` prefixed by the letter "v" (e.g. "v1.0.1")
1. Click the "Generate release notes" button and GitHub will automatically add the relevant details (which you can edit as needed) and a link to a changelog
1. Until we have launched our MVP version of the theme, make sure to select the "Set as a pre-release" checkbox
1. Click the green "Publish release" button

### Keeping Atlas in Sync

After merging anything into the main branch on GitHub, it is also recommended to update the dev environment on the [CD WP Atlas site](https://dashboard.pantheon.io/sites/cfda6aad-f6be-4c46-99dc-5bcb9eb56996), since we're using that as a sandbox for theme and plugin development.

If you already have Atlas set up to work locally (see [Local Development Setup](https://github.com/CornellCustomDev/cd_wp_base/blob/main/CONTRIBUTING.md#local-development-setup) section above), you can:

1. Navigate into the base theme directory (`cd wp-content/themes/cd_wp_base`)
1. Make sure you're on the `main` branch and run `git pull` to pull down the latest changes from GitHub
1. Navigate back out of the theme directory (`cd ../`)
1. You should now be in the Pantheon repo and see changed files; commit these as normal and push them up to the dev site
